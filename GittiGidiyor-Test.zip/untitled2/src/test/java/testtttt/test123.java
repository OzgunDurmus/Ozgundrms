package testtttt;


import javafx.scene.web.WebErrorEvent;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;





public class test123 {

   public WebDriver driver ;
    public void scrollDown ()
    {
        JavascriptExecutor js =(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,500)");
    }



    public static void main(String[] args) throws InterruptedException{

        System.setProperty("webdriver.chrome.driver","drivers/chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.gittigidiyor.com");

        driver.manage().window().maximize();

        WebElement Login = driver.findElement(By.className("egoSnI"));
        Login.click();
        driver.get("https://www.gittigidiyor.com/uye-girisi?s=1");

        Thread.sleep(1000);
        WebElement UserLogin = driver.findElement(By.id("L-UserNameField"));
        UserLogin.click();
        UserLogin.sendKeys("stabilyazilim@gmail.com");
        Thread.sleep(1000);


        WebElement PasswordLogin = driver.findElement(By.id("L-PasswordField"));
        PasswordLogin.click();
        PasswordLogin.sendKeys("Test123!");
        Thread.sleep(1000);

        WebElement loginenter2 = driver.findElement(By.xpath("//*[@id=\"gg-login-enter\"]"));
        loginenter2.click();

        driver.get("https://www.gittigidiyor.com");

        WebElement nameElement = driver.findElement(By.className("dNPmGY"));

        nameElement.click();

        WebElement myElement = driver.findElement(By.className("sc-4995aq-0"));
        myElement.sendKeys("Bilgisayar");

        WebElement SearchElement = driver.findElement(By.className("gaMakD"));
        SearchElement.click();
        Thread.sleep(1000);



        WebElement Page2Element = driver.findElement(By.xpath(".//*[@id=\"__next\"]/main/div[2]"));
        Page2Element.click();

        WebElement CookeiElement = driver.findElement(By.className("policy-alert-v2-buttons"));
        CookeiElement.click();
        Thread.sleep(1000);
        WebElement BasketElement = driver.findElement(By.id("add-to-basket"));
        BasketElement.click();
        Thread.sleep(1000);
        WebElement PriceCheck = driver.findElement(By.id("sp-price-lowPrice"));
        String priceText = PriceCheck.getText();

        Thread.sleep(4000);
        Thread.sleep(500);


       /* WebElement Price2Check = driver.findElement(By.id("product-new-price"));
        String priceText2 = Price2Check.getText();*/


        WebElement BasketElement2 = driver.findElement(By.id("add-to-basket"));
        BasketElement2.click();
        Thread.sleep(500);
        driver.get("https://www.gittigidiyor.com/sepetim");


        WebElement BasketElement3 = driver.findElement(By.className("gg-icon-bin-medium"));
        BasketElement3.click();








    }


}
